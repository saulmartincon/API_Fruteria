namespace FruteriaApp;

static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();

        // Se crea UN SOLO ApiClient y se pasa a todas las pantallas
        var api = new ApiClient("http://127.0.0.1:8000");

        Application.Run(new FormPrincipal(api));
    }
}
