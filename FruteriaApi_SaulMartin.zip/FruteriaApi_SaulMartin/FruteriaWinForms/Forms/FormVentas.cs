using System.ComponentModel;

namespace FruteriaApp;

/// <summary>
/// Pantalla: registro de ventas (carrito + confirmar venta).
/// </summary>
public class FormVentas : Form
{
    private readonly ApiClient _api;
    private List<Producto> _productos = new List<Producto>();

    // BindingList: la tabla se actualiza sola cuando añadimos o quitamos líneas
    private BindingList<LineaVenta> _carrito = new BindingList<LineaVenta>();

    private ComboBox cmbProducto;
    private Label lblInfoProducto;
    private NumericUpDown numKilos;
    private DataGridView dgvCarrito;
    private Label lblTotal;

    public FormVentas(ApiClient api)
    {
        _api = api;
        CrearInterfaz();
        Tema.Aplicar(this);
        Load += async (sender, e) => await CargarProductosAsync();
    }

    private void CrearInterfaz()
    {
        Text = "Registro de ventas";
        Size = new Size(750, 520);
        StartPosition = FormStartPosition.CenterParent;

        // --- Panel de arriba: elegir producto y kilos ---
        var panelArriba = new Panel { Dock = DockStyle.Top, Height = 80 };

        panelArriba.Controls.Add(new Label { Text = "Producto:", Left = 10, Top = 12, Width = 65 });

        cmbProducto = new ComboBox();
        cmbProducto.DropDownStyle = ComboBoxStyle.DropDownList;
        cmbProducto.DisplayMember = "Nombre";   // qué propiedad del Producto se muestra
        cmbProducto.SetBounds(80, 9, 180, 25);
        cmbProducto.SelectedIndexChanged += (sender, e) => MostrarInfoProducto();
        panelArriba.Controls.Add(cmbProducto);

        panelArriba.Controls.Add(new Label { Text = "Kilos:", Left = 280, Top = 12, Width = 40 });

        numKilos = new NumericUpDown();
        numKilos.DecimalPlaces = 2;
        numKilos.Minimum = 0.1M;
        numKilos.Maximum = 10000;
        numKilos.Increment = 0.25M;
        numKilos.Value = 1;
        numKilos.SetBounds(325, 9, 80, 25);
        panelArriba.Controls.Add(numKilos);

        var btnAnadir = new Button { Text = "Añadir al carrito" };
        btnAnadir.SetBounds(425, 7, 130, 30);
        btnAnadir.Click += BtnAnadir_Click;
        panelArriba.Controls.Add(btnAnadir);

        lblInfoProducto = new Label { Left = 10, Top = 48, Width = 600, Height = 25 };
        panelArriba.Controls.Add(lblInfoProducto);

        // --- Tabla del carrito ---
        dgvCarrito = Utilidades.CrearTabla();
        dgvCarrito.ReadOnly = false;   // dejamos editar solo la columna de kilos
        Utilidades.AnadirColumna(dgvCarrito, "Producto", "Nombre").ReadOnly = true;
        Utilidades.AnadirColumna(dgvCarrito, "Kilos", "Kilos", "N2");   // editable
        Utilidades.AnadirColumna(dgvCarrito, "Precio €/kg", "PrecioKg", "N2").ReadOnly = true;
        Utilidades.AnadirColumna(dgvCarrito, "Subtotal €", "Subtotal", "N2").ReadOnly = true;
        dgvCarrito.DataSource = _carrito;
        dgvCarrito.CellValueChanged += DgvCarrito_CellValueChanged;
        dgvCarrito.DataError += (sender, e) =>
        {
            Utilidades.MostrarAviso("Escribe un número válido en los kilos.");
            e.ThrowException = false;
        };

        // --- Panel de abajo: total y botones ---
        var panelAbajo = new Panel { Dock = DockStyle.Bottom, Height = 60 };

        lblTotal = new Label();
        lblTotal.Font = new Font("Segoe UI", 14, FontStyle.Bold);
        lblTotal.SetBounds(10, 15, 220, 30);
        panelAbajo.Controls.Add(lblTotal);

        var btnQuitar = new Button { Text = "Quitar línea" };
        btnQuitar.SetBounds(400, 12, 110, 35);
        btnQuitar.Click += BtnQuitar_Click;
        panelAbajo.Controls.Add(btnQuitar);

        var btnConfirmar = new Button { Text = "Confirmar venta" };
        btnConfirmar.SetBounds(520, 12, 150, 35);
        btnConfirmar.Click += BtnConfirmar_Click;
        panelAbajo.Controls.Add(btnConfirmar);

        Controls.Add(dgvCarrito);
        Controls.Add(panelArriba);
        Controls.Add(panelAbajo);

        ActualizarTotal();
    }

    // ---------------- Cargar productos ----------------
    private async Task CargarProductosAsync()
    {
        try
        {
            _productos = await _api.GetProductosAsync();
            cmbProducto.DataSource = _productos;
            MostrarInfoProducto();
        }
        catch (Exception ex)
        {
            Utilidades.MostrarError("No se pudieron cargar los productos:\n" + ex.Message);
        }
    }

    private void MostrarInfoProducto()
    {
        var producto = cmbProducto.SelectedItem as Producto;
        if (producto == null)
            lblInfoProducto.Text = "";
        else
            lblInfoProducto.Text = $"Precio: {producto.PrecioKg:N2} €/kg   |   Stock disponible: {producto.StockKg:N2} kg";
    }

    // ---------------- Carrito ----------------
    private void BtnAnadir_Click(object sender, EventArgs e)
    {
        var producto = cmbProducto.SelectedItem as Producto;
        if (producto == null) return;

        double kilos = (double)numKilos.Value;

        // ¿Ya está este producto en el carrito? Entonces sumamos los kilos a esa línea
        var linea = _carrito.FirstOrDefault(l => l.ProductoId == producto.Id);
        double kilosYaEnCarrito = linea == null ? 0 : linea.Kilos;

        if (kilosYaEnCarrito + kilos > producto.StockKg)
        {
            Utilidades.MostrarAviso($"No hay suficiente stock. Quedan {producto.StockKg:N2} kg de {producto.Nombre}.");
            return;
        }

        if (linea == null)
        {
            _carrito.Add(new LineaVenta
            {
                ProductoId = producto.Id,
                Nombre = producto.Nombre,
                Kilos = kilos,
                PrecioKg = producto.PrecioKg,
                Subtotal = Math.Round(kilos * producto.PrecioKg, 2)
            });
        }
        else
        {
            linea.Kilos += kilos;
            linea.Subtotal = Math.Round(linea.Kilos * linea.PrecioKg, 2);
            dgvCarrito.Refresh();   // la tabla no se entera sola de que hemos cambiado una línea
        }

        ActualizarTotal();
    }

    private void BtnQuitar_Click(object sender, EventArgs e)
    {
        var linea = dgvCarrito.CurrentRow?.DataBoundItem as LineaVenta;
        if (linea == null) return;

        _carrito.Remove(linea);
        ActualizarTotal();
    }

    // El usuario ha editado los kilos de una línea -> recalculamos subtotal y total
    private void DgvCarrito_CellValueChanged(object sender, DataGridViewCellEventArgs e)
    {
        if (e.RowIndex < 0) return;

        var linea = _carrito[e.RowIndex];
        linea.Subtotal = Math.Round(linea.Kilos * linea.PrecioKg, 2);
        dgvCarrito.InvalidateRow(e.RowIndex);
        ActualizarTotal();
    }

    private void ActualizarTotal()
    {
        double total = _carrito.Sum(l => l.Subtotal);
        lblTotal.Text = $"Total: {total:N2} €";
    }

    // ---------------- Confirmar venta ----------------
    private async void BtnConfirmar_Click(object sender, EventArgs e)
    {
        if (_carrito.Count == 0)
        {
            Utilidades.MostrarAviso("El carrito está vacío.");
            return;
        }

        try
        {
            // La API comprueba el stock, descuenta los kilos y guarda la venta
            Venta venta = await _api.CrearVentaAsync(_carrito.ToList());

            Utilidades.MostrarAviso($"Venta registrada correctamente.\nTotal: {venta.Total:N2} €");

            _carrito.Clear();
            ActualizarTotal();
            await CargarProductosAsync();   // recargamos para ver el stock ya descontado
        }
        catch (Exception ex)
        {
            Utilidades.MostrarError("No se pudo registrar la venta:\n" + ex.Message);
        }
    }
}
