namespace FruteriaApp;

/// <summary>
/// Menú principal: desde aquí se abren todas las pantallas.
/// </summary>
public class FormPrincipal : Form
{
    private readonly ApiClient _api;

    public FormPrincipal(ApiClient api)
    {
        _api = api;

        Text = "Frutería - Menú principal - SaulMartin";
        Size = new Size(360, 340);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;

        var titulo = new Label();
        titulo.Text = "FRUTERÍA - Saul Martin";
        titulo.Font = new Font("Segoe UI", 18, FontStyle.Bold);
        titulo.TextAlign = ContentAlignment.MiddleCenter;
        titulo.SetBounds(20, 15, 300, 40);
        Controls.Add(titulo);

        // Un botón por pantalla; al hacer clic se abre el formulario correspondiente
        CrearBoton("Catálogo de productos", 70, () => new FormCatalogo(_api).ShowDialog());
        CrearBoton("Control de stock", 120, () => new FormStock(_api).ShowDialog());
        CrearBoton("Registro de ventas", 170, () => new FormVentas(_api).ShowDialog());
        CrearBoton("Informes", 220, () => new FormInformes(_api).ShowDialog());

        Tema.Aplicar(this);
    }

    private void CrearBoton(string texto, int top, Action accion)
    {
        var boton = new Button();
        boton.Text = texto;
        boton.SetBounds(50, top, 240, 40);
        boton.Click += (sender, e) => accion();
        Controls.Add(boton);
    }
}
