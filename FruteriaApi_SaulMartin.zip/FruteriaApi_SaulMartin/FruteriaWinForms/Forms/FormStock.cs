namespace FruteriaApp;

/// <summary>
/// Pantalla: control de stock. Pinta de color los productos con poco stock.
/// </summary>
public class FormStock : Form
{
    private const double STOCK_CRITICO = 5;   // por debajo de esto -> rojo

    private readonly ApiClient _api;
    private List<Producto> _todos = new List<Producto>();

    private DataGridView dgv;
    private CheckBox chkSoloBajo;
    private NumericUpDown numUmbral;
    private Label lblResumen;

    public FormStock(ApiClient api)
    {
        _api = api;
        CrearInterfaz();
        Tema.Aplicar(this);
        Load += async (sender, e) => await CargarAsync();
    }

    private void CrearInterfaz()
    {
        Text = "Control de stock";
        Size = new Size(700, 480);
        StartPosition = FormStartPosition.CenterParent;

        dgv = Utilidades.CrearTabla();
        Utilidades.AnadirColumna(dgv, "ID", "Id");
        Utilidades.AnadirColumna(dgv, "Nombre", "Nombre");
        Utilidades.AnadirColumna(dgv, "Categoría", "Categoria");
        Utilidades.AnadirColumna(dgv, "Stock kg", "StockKg", "N2");
        dgv.CellFormatting += Dgv_CellFormatting;   // aquí se pintan los colores

        var panelArriba = new Panel { Dock = DockStyle.Top, Height = 50 };

        chkSoloBajo = new CheckBox();
        chkSoloBajo.Text = "Mostrar solo stock bajo (menos de)";
        chkSoloBajo.SetBounds(10, 14, 240, 25);
        chkSoloBajo.CheckedChanged += (sender, e) => AplicarFiltro();
        panelArriba.Controls.Add(chkSoloBajo);

        numUmbral = new NumericUpDown();
        numUmbral.Minimum = 1;
        numUmbral.Maximum = 100000;
        numUmbral.Value = 10;   // por defecto: bajo = menos de 10 kg
        numUmbral.SetBounds(255, 12, 70, 25);
        numUmbral.ValueChanged += (sender, e) => AplicarFiltro();
        panelArriba.Controls.Add(numUmbral);

        panelArriba.Controls.Add(new Label { Text = "kg", Left = 330, Top = 16, Width = 30 });

        var btnRefrescar = new Button { Text = "Refrescar" };
        btnRefrescar.SetBounds(380, 10, 100, 30);
        btnRefrescar.Click += async (sender, e) => await CargarAsync();
        panelArriba.Controls.Add(btnRefrescar);

        lblResumen = new Label { Dock = DockStyle.Bottom, Height = 30, TextAlign = ContentAlignment.MiddleLeft };
        lblResumen.Text = "  Rojo: stock crítico (menos de 5 kg)   |   Amarillo: stock bajo";

        Controls.Add(dgv);
        Controls.Add(panelArriba);
        Controls.Add(lblResumen);
    }

    private async Task CargarAsync()
    {
        try
        {
            _todos = await _api.GetProductosAsync();
            AplicarFiltro();
        }
        catch (Exception ex)
        {
            Utilidades.MostrarError("No se pudo cargar el stock:\n" + ex.Message);
        }
    }

    private void AplicarFiltro()
    {
        double umbral = (double)numUmbral.Value;

        if (chkSoloBajo.Checked)
            dgv.DataSource = _todos.Where(p => p.StockKg < umbral).ToList();
        else
            dgv.DataSource = _todos.ToList();
    }

    // Se ejecuta para cada celda antes de dibujarla: aquí cambiamos el color de fondo
    private void Dgv_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
    {
        if (e.RowIndex < 0) return;   // la cabecera no se pinta

        var producto = dgv.Rows[e.RowIndex].DataBoundItem as Producto;
        if (producto == null) return;

        if (producto.StockKg < STOCK_CRITICO)
            e.CellStyle.BackColor = Color.LightCoral;
        else if (producto.StockKg < (double)numUmbral.Value)
            e.CellStyle.BackColor = Color.Khaki;
    }
}
