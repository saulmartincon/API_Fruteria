namespace FruteriaApp;

/// <summary>
/// Pantalla: catálogo de productos (CRUD + búsqueda + filtro por categoría).
/// </summary>
public class FormCatalogo : Form
{
    private readonly ApiClient _api;
    private List<Producto> _todos = new List<Producto>();   // todos los productos de la API

    private DataGridView dgv;
    private TextBox txtBuscar;
    private ComboBox cmbCategoria;
    private Button btnRefrescar, btnNuevo, btnEditar, btnEliminar;

    public FormCatalogo(ApiClient api)
    {
        _api = api;
        CrearInterfaz();
        Tema.Aplicar(this);
        Load += async (sender, e) => await CargarProductosAsync();   // al abrir, cargamos datos
    }

    private void CrearInterfaz()
    {
        Text = "Catálogo de productos";
        Size = new Size(800, 500);
        StartPosition = FormStartPosition.CenterParent;

        // --- Tabla ---
        dgv = Utilidades.CrearTabla();
        Utilidades.AnadirColumna(dgv, "ID", "Id");
        Utilidades.AnadirColumna(dgv, "Nombre", "Nombre");
        Utilidades.AnadirColumna(dgv, "Categoría", "Categoria");
        Utilidades.AnadirColumna(dgv, "Precio €/kg", "PrecioKg", "N2");
        Utilidades.AnadirColumna(dgv, "Stock kg", "StockKg", "N2");
        dgv.SelectionChanged += (sender, e) => ActualizarBotones();

        // --- Panel de arriba: búsqueda y filtro ---
        var panelArriba = new Panel { Dock = DockStyle.Top, Height = 45 };

        txtBuscar = new TextBox();
        txtBuscar.PlaceholderText = "Buscar por nombre...";
        txtBuscar.SetBounds(10, 10, 220, 25);
        txtBuscar.TextChanged += (sender, e) => AplicarFiltros();
        panelArriba.Controls.Add(txtBuscar);

        cmbCategoria = new ComboBox();
        cmbCategoria.DropDownStyle = ComboBoxStyle.DropDownList;   // solo se puede elegir
        cmbCategoria.SetBounds(240, 10, 160, 25);
        cmbCategoria.SelectedIndexChanged += (sender, e) => AplicarFiltros();
        panelArriba.Controls.Add(cmbCategoria);

        // --- Panel de abajo: botones ---
        var panelAbajo = new Panel { Dock = DockStyle.Bottom, Height = 50 };

        btnRefrescar = CrearBoton("Refrescar", 10, panelAbajo);
        btnNuevo = CrearBoton("Nuevo", 120, panelAbajo);
        btnEditar = CrearBoton("Editar", 230, panelAbajo);
        btnEliminar = CrearBoton("Eliminar", 340, panelAbajo);

        btnRefrescar.Click += async (sender, e) => await CargarProductosAsync();
        btnNuevo.Click += BtnNuevo_Click;
        btnEditar.Click += BtnEditar_Click;
        btnEliminar.Click += BtnEliminar_Click;

        // IMPORTANTE: primero se añade el control que rellena (Fill) y después los de los bordes
        Controls.Add(dgv);
        Controls.Add(panelArriba);
        Controls.Add(panelAbajo);
    }

    private Button CrearBoton(string texto, int left, Panel panel)
    {
        var boton = new Button();
        boton.Text = texto;
        boton.SetBounds(left, 10, 100, 30);
        panel.Controls.Add(boton);
        return boton;
    }

    // ---------------- Cargar datos ----------------
    private async Task CargarProductosAsync()
    {
        try
        {
            _todos = await _api.GetProductosAsync();
            CargarCategorias();
            AplicarFiltros();
        }
        catch (Exception ex)
        {
            Utilidades.MostrarError("No se pudieron cargar los productos:\n" + ex.Message);
        }
    }

    private void CargarCategorias()
    {
        string seleccionada = cmbCategoria.SelectedItem as string;

        cmbCategoria.Items.Clear();
        cmbCategoria.Items.Add("Todas");
        foreach (string categoria in _todos.Select(p => p.Categoria).Distinct().OrderBy(c => c))
        {
            cmbCategoria.Items.Add(categoria);
        }

        // Intentamos mantener la categoría que estaba elegida
        if (seleccionada != null && cmbCategoria.Items.Contains(seleccionada))
            cmbCategoria.SelectedItem = seleccionada;
        else
            cmbCategoria.SelectedIndex = 0;
    }

    private void AplicarFiltros()
    {
        string texto = txtBuscar.Text.Trim().ToLower();
        string categoria = cmbCategoria.SelectedItem as string ?? "Todas";

        var filtrados = _todos
            .Where(p => p.Nombre.ToLower().Contains(texto))
            .Where(p => categoria == "Todas" || p.Categoria == categoria)
            .ToList();

        dgv.DataSource = filtrados;
        ActualizarBotones();
    }

    // ---------------- Selección ----------------
    private Producto ProductoSeleccionado()
    {
        return dgv.CurrentRow?.DataBoundItem as Producto;
    }

    private void ActualizarBotones()
    {
        bool haySeleccion = ProductoSeleccionado() != null;
        btnEditar.Enabled = haySeleccion;
        btnEliminar.Enabled = haySeleccion;
    }

    // ---------------- Acciones CRUD ----------------
    private async void BtnNuevo_Click(object sender, EventArgs e)
    {
        var formulario = new FormProducto(null, _todos.Select(p => p.Categoria).Distinct().ToList());
        if (formulario.ShowDialog() != DialogResult.OK) return;

        try
        {
            await _api.CrearProductoAsync(formulario.Resultado);
            await CargarProductosAsync();
        }
        catch (Exception ex)
        {
            Utilidades.MostrarError("No se pudo crear el producto:\n" + ex.Message);
        }
    }

    private async void BtnEditar_Click(object sender, EventArgs e)
    {
        var producto = ProductoSeleccionado();
        if (producto == null) return;

        var formulario = new FormProducto(producto, _todos.Select(p => p.Categoria).Distinct().ToList());
        if (formulario.ShowDialog() != DialogResult.OK) return;

        try
        {
            await _api.ActualizarProductoAsync(formulario.Resultado);
            await CargarProductosAsync();
        }
        catch (Exception ex)
        {
            Utilidades.MostrarError("No se pudo actualizar el producto:\n" + ex.Message);
        }
    }

    private async void BtnEliminar_Click(object sender, EventArgs e)
    {
        var producto = ProductoSeleccionado();
        if (producto == null) return;

        var respuesta = MessageBox.Show(
            "¿Seguro que quieres eliminar \"" + producto.Nombre + "\"?",
            "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        if (respuesta != DialogResult.Yes) return;

        try
        {
            await _api.EliminarProductoAsync(producto.Id);
            await CargarProductosAsync();
        }
        catch (Exception ex)
        {
            Utilidades.MostrarError("No se pudo eliminar el producto:\n" + ex.Message);
        }
    }
}
