namespace FruteriaApp;

/// <summary>
/// Pantalla: informe de ventas de hoy + listado de todas las ventas.
/// </summary>
public class FormInformes : Form
{
    private readonly ApiClient _api;

    private Label lblTotal, lblNumero, lblMasVendido;
    private DataGridView dgvVentas;

    public FormInformes(ApiClient api)
    {
        _api = api;
        CrearInterfaz();
        Tema.Aplicar(this);
        Load += async (sender, e) => await CargarAsync();
    }

    private void CrearInterfaz()
    {
        Text = "Informes";
        Size = new Size(600, 480);
        StartPosition = FormStartPosition.CenterParent;

        var panelArriba = new Panel { Dock = DockStyle.Top, Height = 140 };

        lblTotal = CrearEtiqueta(15, panelArriba);
        lblNumero = CrearEtiqueta(45, panelArriba);
        lblMasVendido = CrearEtiqueta(75, panelArriba);

        var btnActualizar = new Button { Text = "Actualizar" };
        btnActualizar.SetBounds(15, 105, 110, 30);
        btnActualizar.Click += async (sender, e) => await CargarAsync();
        panelArriba.Controls.Add(btnActualizar);

        dgvVentas = Utilidades.CrearTabla();
        Utilidades.AnadirColumna(dgvVentas, "ID", "Id");
        Utilidades.AnadirColumna(dgvVentas, "Fecha", "Fecha");
        Utilidades.AnadirColumna(dgvVentas, "Total €", "Total", "N2");

        Controls.Add(dgvVentas);
        Controls.Add(panelArriba);
    }

    private Label CrearEtiqueta(int top, Panel panel)
    {
        var etiqueta = new Label();
        etiqueta.Font = new Font("Segoe UI", 11);
        etiqueta.SetBounds(15, top, 540, 28);
        panel.Controls.Add(etiqueta);
        return etiqueta;
    }

    private async Task CargarAsync()
    {
        try
        {
            InformeHoy informe = await _api.GetInformeHoyAsync();
            lblTotal.Text = $"Total vendido hoy: {informe.TotalVendido:N2} €";
            lblNumero.Text = $"Número de ventas: {informe.NumeroVentas}";
            lblMasVendido.Text = "Producto más vendido: " + (informe.ProductoMasVendido ?? "-");

            dgvVentas.DataSource = await _api.GetVentasAsync();
        }
        catch (Exception ex)
        {
            Utilidades.MostrarError("No se pudo cargar el informe:\n" + ex.Message);
        }
    }
}
