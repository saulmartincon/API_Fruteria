namespace FruteriaApp;

/// <summary>
/// Ventana pequeña para crear o editar un producto.
/// Si el usuario pulsa Guardar, el resultado queda en la propiedad Resultado.
/// </summary>
public class FormProducto : Form
{
    public Producto Resultado { get; private set; }

    private readonly int _id;   // 0 si es un producto nuevo
    private TextBox txtNombre;
    private ComboBox cmbCategoria;
    private NumericUpDown numPrecio;
    private NumericUpDown numStock;

    // producto = null -> estamos creando uno nuevo
    public FormProducto(Producto producto, List<string> categorias)
    {
        CrearInterfaz(categorias);
        Tema.Aplicar(this);

        if (producto != null)
        {
            Text = "Editar producto";
            _id = producto.Id;
            txtNombre.Text = producto.Nombre;
            cmbCategoria.Text = producto.Categoria;
            numPrecio.Value = (decimal)producto.PrecioKg;
            numStock.Value = (decimal)producto.StockKg;
        }
    }

    private void CrearInterfaz(List<string> categorias)
    {
        Text = "Nuevo producto";
        Size = new Size(340, 280);
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;

        AnadirEtiqueta("Nombre:", 20);
        txtNombre = new TextBox();
        txtNombre.SetBounds(120, 17, 180, 25);
        Controls.Add(txtNombre);

        AnadirEtiqueta("Categoría:", 60);
        cmbCategoria = new ComboBox();
        cmbCategoria.DropDownStyle = ComboBoxStyle.DropDown;   // permite escribir una categoría nueva
        cmbCategoria.Items.AddRange(categorias.ToArray());
        cmbCategoria.SetBounds(120, 57, 180, 25);
        Controls.Add(cmbCategoria);

        AnadirEtiqueta("Precio (€/kg):", 100);
        numPrecio = new NumericUpDown();
        numPrecio.DecimalPlaces = 2;
        numPrecio.Increment = 0.10M;
        numPrecio.Maximum = 100000;
        numPrecio.SetBounds(120, 97, 100, 25);
        Controls.Add(numPrecio);

        AnadirEtiqueta("Stock (kg):", 140);
        numStock = new NumericUpDown();
        numStock.DecimalPlaces = 2;
        numStock.Increment = 1;
        numStock.Maximum = 100000;
        numStock.SetBounds(120, 137, 100, 25);
        Controls.Add(numStock);

        var btnGuardar = new Button();
        btnGuardar.Text = "Guardar";
        btnGuardar.SetBounds(60, 190, 90, 30);
        btnGuardar.Click += BtnGuardar_Click;
        Controls.Add(btnGuardar);

        var btnCancelar = new Button();
        btnCancelar.Text = "Cancelar";
        btnCancelar.SetBounds(170, 190, 90, 30);
        btnCancelar.DialogResult = DialogResult.Cancel;   // cierra la ventana sin guardar
        Controls.Add(btnCancelar);
    }

    private void AnadirEtiqueta(string texto, int top)
    {
        var etiqueta = new Label();
        etiqueta.Text = texto;
        etiqueta.SetBounds(20, top, 95, 25);
        Controls.Add(etiqueta);
    }

    private void BtnGuardar_Click(object sender, EventArgs e)
    {
        // Validaciones sencillas antes de cerrar
        if (txtNombre.Text.Trim() == "")
        {
            Utilidades.MostrarAviso("Escribe el nombre del producto.");
            return;
        }
        if (cmbCategoria.Text.Trim() == "")
        {
            Utilidades.MostrarAviso("Escribe o elige una categoría.");
            return;
        }

        Resultado = new Producto
        {
            Id = _id,
            Nombre = txtNombre.Text.Trim(),
            Categoria = cmbCategoria.Text.Trim(),
            PrecioKg = (double)numPrecio.Value,
            StockKg = (double)numStock.Value
        };
        DialogResult = DialogResult.OK;   // esto cierra la ventana y avisa de que se guardó
    }
}
