namespace FruteriaApp;

// Una línea del carrito (producto + kilos)
public class LineaVenta
{
    public int ProductoId { get; set; }
    public string Nombre { get; set; }
    public double Kilos { get; set; }
    public double PrecioKg { get; set; }
    public double Subtotal { get; set; }
}
