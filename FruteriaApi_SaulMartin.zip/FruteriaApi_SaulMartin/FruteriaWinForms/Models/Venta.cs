namespace FruteriaApp;

public class Venta
{
    public int Id { get; set; }
    public string Fecha { get; set; }
    public List<LineaVenta> Lineas { get; set; }
    public double Total { get; set; }
}
