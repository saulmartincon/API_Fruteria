namespace FruteriaApp;

public class InformeHoy
{
    public double TotalVendido { get; set; }
    public int NumeroVentas { get; set; }
    public string ProductoMasVendido { get; set; }
}
