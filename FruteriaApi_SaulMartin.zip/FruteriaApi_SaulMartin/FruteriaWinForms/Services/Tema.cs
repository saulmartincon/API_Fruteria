namespace FruteriaApp;

/// <summary>
/// Colores de la aplicación. Solo hay dos: cambia los números y cambia todo.
/// </summary>
public static class Tema
{
    public static readonly Color Verde = Color.FromArgb(46, 125, 50);    // botones y cabecera de las tablas
    public static readonly Color Fondo = Color.FromArgb(245, 250, 243);  // fondo de las ventanas

    // Se llama al final del constructor de cada pantalla
    public static void Aplicar(Form formulario)
    {
        formulario.BackColor = Fondo;
        Pintar(formulario);
    }

    // Recorre todos los controles (también los que están dentro de paneles)
    private static void Pintar(Control padre)
    {
        foreach (Control c in padre.Controls)
        {
            if (c is Button boton)
            {
                boton.FlatStyle = FlatStyle.Flat;
                boton.FlatAppearance.BorderSize = 0;
                boton.BackColor = Verde;
                boton.ForeColor = Color.White;
            }
            else if (c is DataGridView tabla)
            {
                tabla.EnableHeadersVisualStyles = false;
                tabla.ColumnHeadersDefaultCellStyle.BackColor = Verde;
                tabla.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                tabla.ColumnHeadersDefaultCellStyle.SelectionBackColor = Verde;
            }
            else
            {
                Pintar(c);
            }
        }
    }
}
