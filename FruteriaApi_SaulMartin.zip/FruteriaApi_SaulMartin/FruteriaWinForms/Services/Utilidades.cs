namespace FruteriaApp;

/// <summary>
/// Pequeñas ayudas para no repetir código en todas las pantallas.
/// </summary>
public static class Utilidades
{
    // Crea un DataGridView ya configurado (solo lectura, fila completa, sin filas vacías)
    public static DataGridView CrearTabla()
    {
        var tabla = new DataGridView();
        tabla.Dock = DockStyle.Fill;
        tabla.ReadOnly = true;
        tabla.AllowUserToAddRows = false;
        tabla.AllowUserToDeleteRows = false;
        tabla.RowHeadersVisible = false;
        tabla.MultiSelect = false;
        tabla.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        tabla.AutoGenerateColumns = false;   // las columnas las definimos nosotros
        tabla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        tabla.BackgroundColor = Color.White;
        return tabla;
    }

    // Añade una columna: titulo = lo que se ve, propiedad = nombre de la propiedad C#
    public static DataGridViewTextBoxColumn AnadirColumna(DataGridView tabla, string titulo, string propiedad, string formato = null)
    {
        var columna = new DataGridViewTextBoxColumn();
        columna.HeaderText = titulo;
        columna.DataPropertyName = propiedad;
        if (formato != null) columna.DefaultCellStyle.Format = formato;
        tabla.Columns.Add(columna);
        return columna;
    }

    public static void MostrarError(string mensaje)
    {
        MessageBox.Show(mensaje, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }

    public static void MostrarAviso(string mensaje)
    {
        MessageBox.Show(mensaje, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
}
