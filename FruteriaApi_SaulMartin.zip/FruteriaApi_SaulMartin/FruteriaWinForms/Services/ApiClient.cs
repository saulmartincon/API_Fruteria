using System.Net.Http.Json;
using System.Text.Json;

namespace FruteriaApp;

/// <summary>
/// Única clase que habla con la API. Las pantallas NUNCA usan HttpClient directamente.
/// </summary>
public class ApiClient
{
    private readonly HttpClient _http;

    // JsonSerializerDefaults.Web -> usa camelCase (precioKg) y no distingue mayúsculas
    // Así la propiedad C# "PrecioKg" encaja con el campo JSON "precioKg"
    private readonly JsonSerializerOptions _json = new JsonSerializerOptions(JsonSerializerDefaults.Web);

    public ApiClient(string urlBase)
    {
        _http = new HttpClient { BaseAddress = new Uri(urlBase) };
    }

    // ---------------- PRODUCTOS ----------------
    public async Task<List<Producto>> GetProductosAsync()
    {
        var respuesta = await _http.GetAsync("/productos");
        return await LeerAsync<List<Producto>>(respuesta);
    }

    public async Task<Producto> CrearProductoAsync(Producto producto)
    {
        var respuesta = await _http.PostAsJsonAsync("/productos", producto, _json);
        return await LeerAsync<Producto>(respuesta);
    }

    public async Task ActualizarProductoAsync(Producto producto)
    {
        var respuesta = await _http.PutAsJsonAsync("/productos/" + producto.Id, producto, _json);
        await ComprobarAsync(respuesta);
    }

    public async Task EliminarProductoAsync(int id)
    {
        var respuesta = await _http.DeleteAsync("/productos/" + id);
        await ComprobarAsync(respuesta);
    }

    // ---------------- VENTAS ----------------
    public async Task<Venta> CrearVentaAsync(List<LineaVenta> lineas)
    {
        // Solo enviamos lo que la API necesita: productoId y kilos
        var cuerpo = new
        {
            lineas = lineas.Select(l => new { productoId = l.ProductoId, kilos = l.Kilos }).ToList()
        };
        var respuesta = await _http.PostAsJsonAsync("/ventas", cuerpo, _json);
        return await LeerAsync<Venta>(respuesta);
    }

    public async Task<List<Venta>> GetVentasAsync()
    {
        var respuesta = await _http.GetAsync("/ventas");
        return await LeerAsync<List<Venta>>(respuesta);
    }

    // ---------------- INFORMES ----------------
    public async Task<InformeHoy> GetInformeHoyAsync()
    {
        var respuesta = await _http.GetAsync("/informes/ventas-hoy");
        return await LeerAsync<InformeHoy>(respuesta);
    }

    // ---------------- AYUDAS INTERNAS ----------------

    // Si la respuesta es correcta, convierte el JSON en objetos C#
    private async Task<T> LeerAsync<T>(HttpResponseMessage respuesta)
    {
        await ComprobarAsync(respuesta);
        return await respuesta.Content.ReadFromJsonAsync<T>(_json);
    }

    // Si la API devuelve un error (404, 400...), lanza una Exception con el mensaje
    private async Task ComprobarAsync(HttpResponseMessage respuesta)
    {
        if (respuesta.IsSuccessStatusCode) return;

        string mensaje = "Error " + (int)respuesta.StatusCode;
        try
        {
            string texto = await respuesta.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(texto);
            // FastAPI devuelve los errores así: {"detail": "mensaje"}
            if (doc.RootElement.TryGetProperty("detail", out var detalle)
                && detalle.ValueKind == JsonValueKind.String)
            {
                mensaje = detalle.GetString();
            }
            else
            {
                mensaje = "Datos no válidos (error " + (int)respuesta.StatusCode + ")";
            }
        }
        catch
        {
            // Si no podemos leer el detalle, nos quedamos con el mensaje genérico
        }
        throw new Exception(mensaje);
    }
}
