"""
API REST de la frutería (FastAPI).

Cómo arrancarla (desde esta carpeta):
    pip install -r requirements.txt
    uvicorn main:app --reload

Documentación automática (para probar los endpoints desde el navegador):
    http://127.0.0.1:8000/docs
"""

import json
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="API Frutería")

# Fichero donde guardamos los datos (se crea solo la primera vez)
FICHERO = Path(__file__).parent / "datos.json"


# ---------------------------------------------------------------
# 1. MODELOS (la forma que tienen los datos que entran por la API)
# ---------------------------------------------------------------
class ProductoNuevo(BaseModel):
    """Datos que envía el cliente para crear o modificar un producto."""
    nombre: str
    categoria: str
    precioKg: float = Field(ge=0)   # ge=0 -> mayor o igual que 0
    stockKg: float = Field(ge=0)


class Producto(ProductoNuevo):
    """Un producto completo: lo mismo que ProductoNuevo + el id."""
    id: int


class LineaVentaNueva(BaseModel):
    """Una línea del carrito: qué producto y cuántos kilos."""
    productoId: int
    kilos: float = Field(gt=0)      # gt=0 -> estrictamente mayor que 0


class VentaNueva(BaseModel):
    """Una venta es una lista de líneas."""
    lineas: list[LineaVentaNueva]


# ---------------------------------------------------------------
# 2. DATOS (en memoria + guardados en un fichero JSON)
# ---------------------------------------------------------------
def datos_iniciales() -> dict:
    """Datos de ejemplo para que la app no empiece vacía."""
    return {
        "productos": [
            {"id": 1, "nombre": "Manzana", "categoria": "Fruta", "precioKg": 2.10, "stockKg": 50},
            {"id": 2, "nombre": "Plátano", "categoria": "Fruta", "precioKg": 1.80, "stockKg": 40},
            {"id": 3, "nombre": "Naranja", "categoria": "Fruta", "precioKg": 1.50, "stockKg": 8},
            {"id": 4, "nombre": "Tomate", "categoria": "Verdura", "precioKg": 2.80, "stockKg": 25},
            {"id": 5, "nombre": "Lechuga", "categoria": "Verdura", "precioKg": 1.20, "stockKg": 3},
        ],
        "ventas": [],
    }


def cargar_datos() -> dict:
    """Lee el fichero JSON. Si no existe, crea los datos de ejemplo."""
    if FICHERO.exists():
        with open(FICHERO, "r", encoding="utf-8") as f:
            return json.load(f)
    datos = datos_iniciales()
    guardar_datos(datos)
    return datos


def guardar_datos(datos: dict) -> None:
    """Escribe todos los datos en el fichero JSON."""
    with open(FICHERO, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)


# Esta variable global guarda productos y ventas mientras la API está en marcha
datos = cargar_datos()


def buscar_producto(id: int):
    """Devuelve el producto con ese id, o None si no existe."""
    for p in datos["productos"]:
        if p["id"] == id:
            return p
    return None


def siguiente_id(lista: list) -> int:
    """Calcula el siguiente id libre de una lista (máximo + 1)."""
    if len(lista) == 0:
        return 1
    return max(elemento["id"] for elemento in lista) + 1


# ---------------------------------------------------------------
# 3. ENDPOINTS DE PRODUCTOS (CRUD)
# ---------------------------------------------------------------
@app.get("/productos")
def listar_productos():
    return datos["productos"]


@app.post("/productos", status_code=201)
def crear_producto(nuevo: ProductoNuevo):
    producto = nuevo.model_dump()                       # pasamos el modelo a diccionario
    producto["id"] = siguiente_id(datos["productos"])   # el id lo pone la API
    datos["productos"].append(producto)
    guardar_datos(datos)
    return producto


@app.put("/productos/{id}")
def actualizar_producto(id: int, nuevo: ProductoNuevo):
    producto = buscar_producto(id)
    if producto is None:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    producto["nombre"] = nuevo.nombre
    producto["categoria"] = nuevo.categoria
    producto["precioKg"] = nuevo.precioKg
    producto["stockKg"] = nuevo.stockKg
    guardar_datos(datos)
    return producto


@app.delete("/productos/{id}")
def eliminar_producto(id: int):
    producto = buscar_producto(id)
    if producto is None:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    datos["productos"].remove(producto)
    guardar_datos(datos)
    return {"ok": True}


# ---------------------------------------------------------------
# 4. ENDPOINTS DE VENTAS
# ---------------------------------------------------------------
@app.post("/ventas", status_code=201)
def registrar_venta(venta: VentaNueva):
    if len(venta.lineas) == 0:
        raise HTTPException(status_code=400, detail="La venta no tiene productos")

    # PASO 1: sumar los kilos pedidos de cada producto
    # (por si el mismo producto aparece en dos líneas)
    kilos_pedidos = {}
    for linea in venta.lineas:
        kilos_pedidos[linea.productoId] = kilos_pedidos.get(linea.productoId, 0) + linea.kilos

    # PASO 2: comprobar que todo existe y que hay stock ANTES de tocar nada
    for producto_id, kilos in kilos_pedidos.items():
        producto = buscar_producto(producto_id)
        if producto is None:
            raise HTTPException(status_code=404, detail=f"El producto {producto_id} no existe")
        if kilos > producto["stockKg"]:
            raise HTTPException(
                status_code=400,
                detail=f"Stock insuficiente de {producto['nombre']}: quedan {producto['stockKg']} kg",
            )

    # PASO 3: todo correcto -> construimos la venta y descontamos el stock
    lineas_venta = []
    total = 0.0
    for linea in venta.lineas:
        producto = buscar_producto(linea.productoId)
        subtotal = round(linea.kilos * producto["precioKg"], 2)
        total += subtotal
        producto["stockKg"] = round(producto["stockKg"] - linea.kilos, 2)
        lineas_venta.append({
            "productoId": producto["id"],
            "nombre": producto["nombre"],
            "kilos": linea.kilos,
            "precioKg": producto["precioKg"],
            "subtotal": subtotal,
        })

    nueva_venta = {
        "id": siguiente_id(datos["ventas"]),
        "fecha": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "lineas": lineas_venta,
        "total": round(total, 2),
    }
    datos["ventas"].append(nueva_venta)
    guardar_datos(datos)
    return nueva_venta


@app.get("/ventas")
def listar_ventas():
    return datos["ventas"]


# ---------------------------------------------------------------
# 5. INFORME (opcional)
# ---------------------------------------------------------------
@app.get("/informes/ventas-hoy")
def informe_ventas_hoy():
    hoy = datetime.now().strftime("%Y-%m-%d")
    ventas_hoy = [v for v in datos["ventas"] if v["fecha"].startswith(hoy)]

    total = round(sum(v["total"] for v in ventas_hoy), 2)

    # Kilos vendidos de cada producto, para saber cuál es el más vendido
    kilos_por_producto = {}
    for v in ventas_hoy:
        for linea in v["lineas"]:
            nombre = linea["nombre"]
            kilos_por_producto[nombre] = kilos_por_producto.get(nombre, 0) + linea["kilos"]

    if len(kilos_por_producto) > 0:
        mas_vendido = max(kilos_por_producto, key=kilos_por_producto.get)
    else:
        mas_vendido = None

    return {
        "totalVendido": total,
        "numeroVentas": len(ventas_hoy),
        "productoMasVendido": mas_vendido,
    }
